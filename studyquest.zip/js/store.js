// データの保存・読み込み(ブラウザのlocalStorage)
const KEY = 'studyquest.v1';

const uid = () => Math.random().toString(36).slice(2, 9);

function todayStr(d = new Date()) {
  const z = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
  return z.toISOString().slice(0, 10);
}

function defaults() {
  return {
    name: '',
    theme: 'auto',
    focus: { work: 25, rest: 5 },
    subjects: [
      { id: 'prime', name: 'プライム', emoji: '📘', color: '#5b6cff', unit: 'ページ', total: 10, done: 0 },
      { id: 'kobun', name: 'プログレス古文', emoji: '📜', color: '#f97316', unit: '回', total: 10, done: 0 },
      { id: 'kanbun', name: 'プログレス漢文', emoji: '🈴', color: '#14b8a6', unit: '回', total: 10, done: 0 },
      { id: 'math', name: '土曜課外 数学プリント', emoji: '➗', color: '#a855f7', unit: '枚', total: 10, done: 0 }
    ],
    tasks: [],
    log: [] // { d:'2026-11-24', t:'task'|'unit'|'focus', n:数, s:教科id }
  };
}

const Store = {
  load() {
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) return defaults();
      return Object.assign(defaults(), JSON.parse(raw));
    } catch (e) {
      return defaults();
    }
  },
  save(state) {
    try {
      state.log = state.log.slice(-1500);
      localStorage.setItem(KEY, JSON.stringify(state));
    } catch (e) {
      console.warn('保存できませんでした', e);
    }
  },
  clear() {
    try { localStorage.removeItem(KEY); } catch (e) {}
  }
};
