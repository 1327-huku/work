// かんたん紙吹雪
const Confetti = (() => {
  const cv = document.getElementById('confetti');
  const ctx = cv.getContext('2d');
  let parts = [], running = false;
  const colors = ['#5b6cff', '#22d3ee', '#f97316', '#a855f7', '#22c55e', '#facc15', '#f43f5e'];

  function resize() {
    cv.width = innerWidth * devicePixelRatio;
    cv.height = innerHeight * devicePixelRatio;
  }
  addEventListener('resize', resize);
  resize();

  function burst(count = 90) {
    const dpr = devicePixelRatio;
    for (let i = 0; i < count; i++) {
      parts.push({
        x: cv.width / 2, y: cv.height * 0.35,
        vx: (Math.random() - 0.5) * 14 * dpr,
        vy: (Math.random() * -12 - 4) * dpr,
        g: 0.35 * dpr, s: (Math.random() * 7 + 4) * dpr,
        r: Math.random() * 6, vr: (Math.random() - 0.5) * 0.4,
        c: colors[(Math.random() * colors.length) | 0], life: 110
      });
    }
    if (!running) { running = true; requestAnimationFrame(tick); }
  }

  function tick() {
    ctx.clearRect(0, 0, cv.width, cv.height);
    parts.forEach(p => {
      p.vy += p.g; p.x += p.vx; p.y += p.vy; p.r += p.vr; p.life--;
      ctx.save();
      ctx.translate(p.x, p.y); ctx.rotate(p.r);
      ctx.globalAlpha = Math.max(0, Math.min(1, p.life / 40));
      ctx.fillStyle = p.c;
      ctx.fillRect(-p.s / 2, -p.s / 4, p.s, p.s / 2);
      ctx.restore();
    });
    parts = parts.filter(p => p.life > 0);
    if (parts.length) requestAnimationFrame(tick);
    else { running = false; ctx.clearRect(0, 0, cv.width, cv.height); }
  }
  return { burst };
})();
