// StudyQuest メインスクリプト
let S = Store.load();
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const subj = (id) => S.subjects.find(s => s.id === id);
const save = () => { Store.save(S); render(); };

function logAdd(t, n, s) { S.log.push({ d: todayStr(), t, n, s }); }

function toast(msg) {
  const el = $('toast');
  el.textContent = msg; el.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.remove('show'), 2200);
}

function daysUntil(dateStr) {
  const a = new Date(todayStr() + 'T00:00:00');
  const b = new Date(dateStr + 'T00:00:00');
  return Math.round((b - a) / 864e5);
}
function dueBadge(dateStr, done) {
  if (!dateStr) return '';
  const d = daysUntil(dateStr);
  if (done) return `<span class="badge ok">${dateStr.slice(5).replace('-', '/')}</span>`;
  if (d < 0) return `<span class="badge late">${-d}日超過</span>`;
  if (d === 0) return `<span class="badge late">今日まで</span>`;
  if (d === 1) return `<span class="badge soon">明日まで</span>`;
  if (d <= 3) return `<span class="badge soon">あと${d}日</span>`;
  return `<span class="badge">あと${d}日</span>`;
}

// ---------- テーマ ----------
function applyTheme() {
  const dark = S.theme === 'dark' || (S.theme === 'auto' && matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
}

// ---------- ホーム ----------
function streak() {
  const days = new Set(S.log.map(l => l.d));
  let n = 0;
  const d = new Date();
  if (!days.has(todayStr(d))) d.setDate(d.getDate() - 1); // 今日まだなら昨日から数える
  while (days.has(todayStr(d))) { n++; d.setDate(d.getDate() - 1); }
  return n;
}

function renderHome() {
  const h = new Date().getHours();
  const hello = h < 5 ? 'おつかれさま' : h < 11 ? 'おはよう' : h < 18 ? 'こんにちは' : 'こんばんは';
  $('greet').textContent = hello + (S.name ? '、' + S.name + 'さん' : '');

  const total = S.subjects.reduce((a, s) => a + s.total, 0);
  const done = S.subjects.reduce((a, s) => a + Math.min(s.done, s.total), 0);
  const pct = total ? Math.round(done / total * 100) : 0;
  $('ringPct').textContent = pct + '%';
  $('ringFg').style.strokeDashoffset = 326.7 * (1 - pct / 100);

  const td = todayStr();
  const tdone = S.tasks.filter(t => t.done).length;
  $('stStreak').textContent = streak() + '日';
  $('stTasks').textContent = `${tdone}/${S.tasks.length}`;
  $('stToday').textContent = S.log.filter(l => l.d === td && l.t !== 'focus').reduce((a, l) => a + l.n, 0);
  $('stFocus').textContent = S.log.filter(l => l.d === td && l.t === 'focus').reduce((a, l) => a + l.n, 0);

  // 次の締切
  const next = S.tasks.filter(t => !t.done && t.due).sort((a, b) => a.due.localeCompare(b.due)).slice(0, 4);
  $('nextList').innerHTML = next.length ? next.map(t => {
    const s = subj(t.subject);
    return `<div class="next"><span style="font-size:22px">${s ? esc(s.emoji) : '📝'}</span>
      <div class="t"><b>${esc(t.title)}</b><small>${s ? esc(s.name) : ''}</small></div>${dueBadge(t.due)}</div>`;
  }).join('') : '<p class="muted">締切のある未完了の課題はありません 🎉</p>';

  // 教科カード
  $('subjects').innerHTML = S.subjects.map(s => {
    const p = s.total ? Math.round(Math.min(s.done, s.total) / s.total * 100) : 0;
    return `<div class="card subj" style="--c:${esc(s.color)}">
      <div class="subj-head"><span class="emoji">${esc(s.emoji)}</span><span class="name">${esc(s.name)}</span><span class="pct">${p}%</span>
        <button class="chip" data-action="edit-subject" data-id="${s.id}">編集</button></div>
      <div class="bar"><i style="width:${p}%"></i></div>
      <div class="subj-foot"><span class="cnt">${s.done} / ${s.total} ${esc(s.unit)}${p >= 100 ? ' 🎉 完了!' : ''}</span>
        <button class="step" data-action="dec" data-id="${s.id}">−</button>
        <button class="step plus" data-action="inc" data-id="${s.id}">＋</button></div>
    </div>`;
  }).join('') || '<p class="muted">教科がありません。「＋ 教科を追加」から作成してください。</p>';

  // 7日間グラフ
  const days = [];
  for (let i = 6; i >= 0; i--) { const d = new Date(); d.setDate(d.getDate() - i); days.push(d); }
  const vals = days.map(d => S.log.filter(l => l.d === todayStr(d) && l.t !== 'focus').reduce((a, l) => a + l.n, 0));
  const max = Math.max(1, ...vals);
  const wd = ['日', '月', '火', '水', '木', '金', '土'];
  $('chart').innerHTML = days.map((d, i) =>
    `<div class="col ${i === 6 ? 'today' : ''}"><span class="n">${vals[i] || ''}</span>
     <div class="b" style="height:${vals[i] / max * 85}%"></div><small>${wd[d.getDay()]}</small></div>`).join('');
}

// ---------- 課題 ----------
let filt = { status: 'all', subject: 'all', q: '' };

function fillSubjectSelects() {
  const opts = S.subjects.map(s => `<option value="${s.id}">${esc(s.emoji)} ${esc(s.name)}</option>`).join('');
  const cur = { t: $('tSubject').value, f: $('fSubject').value, m: $('timerSubject').value };
  $('tSubject').innerHTML = opts;
  $('fSubject').innerHTML = '<option value="all">全教科</option>' + opts;
  $('timerSubject').innerHTML = opts;
  if (cur.t) $('tSubject').value = cur.t;
  $('fSubject').value = cur.f || 'all';
  if (cur.m) $('timerSubject').value = cur.m;
}

function renderTasks() {
  let list = S.tasks.filter(t =>
    (filt.status === 'all' || (filt.status === 'done') === t.done) &&
    (filt.subject === 'all' || t.subject === filt.subject) &&
    (!filt.q || t.title.toLowerCase().includes(filt.q.toLowerCase())));
  list.sort((a, b) => (a.done - b.done) || (a.due || '9999').localeCompare(b.due || '9999') || (b.prio - a.prio));
  $('taskList').innerHTML = list.length ? list.map(t => {
    const s = subj(t.subject);
    const pr = ['🟢', '🟡', '🔴'][t.prio] || '';
    return `<li class="task ${t.done ? 'done' : ''}" style="--c:${s ? esc(s.color) : '#5b6cff'}">
      <input type="checkbox" data-action="toggle" data-id="${t.id}" ${t.done ? 'checked' : ''} aria-label="完了">
      <div class="body"><div class="title">${esc(t.title)}</div>
        <div class="meta"><span>${s ? esc(s.emoji + ' ' + s.name) : ''}</span><span>${pr}</span>${dueBadge(t.due, t.done)}</div></div>
      <button class="del" data-action="del-task" data-id="${t.id}" aria-label="削除">🗑</button></li>`;
  }).join('') : '<li class="empty">課題がありません。<br>上のフォームから追加しましょう ✨</li>';
}

// ---------- タイマー ----------
const T = { mode: 'work', left: 25 * 60, end: 0, run: false, iv: null };

function fmt(sec) { return String(Math.floor(sec / 60)).padStart(2, '0') + ':' + String(sec % 60).padStart(2, '0'); }

function timerRender() {
  $('timerFace').textContent = fmt(T.left);
  $('timerMode').textContent = T.mode === 'work' ? '集中モード' : '休憩モード ☕';
  $('timerBtn').textContent = T.run ? '一時停止' : 'スタート';
  document.title = T.run ? `${fmt(T.left)} StudyQuest` : 'StudyQuest 課題トラッカー';
}

function timerReset(mode = 'work') {
  clearInterval(T.iv); T.run = false; T.mode = mode;
  T.left = (mode === 'work' ? S.focus.work : S.focus.rest) * 60;
  timerRender();
}

function timerTick() {
  T.left = Math.max(0, Math.round((T.end - Date.now()) / 1000));
  if (T.left <= 0) {
    const wasWork = T.mode === 'work';
    if (wasWork) { logAdd('focus', S.focus.work, $('timerSubject').value); Store.save(S); Confetti.burst(60); renderHome(); renderFocus(); }
    if (navigator.vibrate) navigator.vibrate([200, 100, 200]);
    toast(wasWork ? `${S.focus.work}分おつかれさま!休憩しよう☕` : '休憩おわり!次いこう💪');
    timerReset(wasWork ? 'rest' : 'work');
    return;
  }
  timerRender();
}

function timerToggle() {
  if (T.run) { clearInterval(T.iv); T.run = false; timerRender(); return; }
  T.run = true; T.end = Date.now() + T.left * 1000;
  T.iv = setInterval(timerTick, 500);
  timerRender();
}

function renderFocus() {
  const sums = S.subjects.map(s => ({ s, m: S.log.filter(l => l.t === 'focus' && l.s === s.id).reduce((a, l) => a + l.n, 0) }));
  const max = Math.max(1, ...sums.map(x => x.m));
  $('focusStats').innerHTML = sums.map(x =>
    `<div class="fstat"><span>${esc(x.s.emoji)}</span><div class="bar" style="--c:${esc(x.s.color)}"><i style="width:${x.m / max * 100}%"></i></div><b>${x.m}分</b></div>`).join('');
}

// ---------- 教科の編集ダイアログ ----------
let editingId = null;
function openSubject(id) {
  editingId = id;
  const s = id ? subj(id) : { name: '', emoji: '📚', color: '#5b6cff', unit: 'ページ', total: 10, done: 0 };
  $('sdTitle').textContent = id ? '教科を編集' : '教科を追加';
  $('sdName').value = s.name; $('sdEmoji').value = s.emoji; $('sdColor').value = s.color;
  $('sdUnit').value = s.unit; $('sdTotal').value = s.total; $('sdDone').value = s.done;
  $('sdDelete').style.display = id ? '' : 'none';
  $('subjectDialog').showModal();
}

// ---------- 全体描画 ----------
function render() {
  applyTheme();
  fillSubjectSelects();
  renderHome();
  renderTasks();
  renderFocus();
  $('sName').value = S.name; $('sTheme').value = S.theme;
  $('workMin').value = S.focus.work; $('restMin').value = S.focus.rest;
  if (!T.run) timerReset(T.mode);
}

// ---------- イベント ----------
document.addEventListener('click', (e) => {
  const tab = e.target.closest('[data-tab]');
  if (tab) {
    document.querySelectorAll('.tabbar button').forEach(b => b.classList.toggle('on', b === tab));
    document.querySelectorAll('.view').forEach(v => v.classList.toggle('active', v.id === 'view-' + tab.dataset.tab));
    scrollTo({ top: 0 });
    return;
  }
  const el = e.target.closest('[data-action]');
  if (!el) return;
  const id = el.dataset.id;
  switch (el.dataset.action) {
    case 'toggle-theme':
      S.theme = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'; save(); break;
    case 'inc': case 'dec': {
      const s = subj(id); const before = s.done;
      s.done = Math.max(0, Math.min(s.total, s.done + (el.dataset.action === 'inc' ? 1 : -1)));
      if (s.done > before) { logAdd('unit', 1, s.id); if (s.done === s.total) { Confetti.burst(160); toast(`${s.name} 完了!すごい🎉`); } }
      save(); break;
    }
    case 'edit-subject': openSubject(id); break;
    case 'add-subject': openSubject(null); break;
    case 'toggle': {
      const t = S.tasks.find(x => x.id === id); t.done = el.checked;
      if (t.done) { logAdd('task', 1, t.subject); Confetti.burst(40);
        if (S.tasks.every(x => x.done)) { Confetti.burst(160); toast('全課題クリア!最高🏆'); } }
      save(); break;
    }
    case 'del-task':
      if (confirm('この課題を削除しますか?')) { S.tasks = S.tasks.filter(x => x.id !== id); save(); } break;
    case 'timer-toggle': timerToggle(); break;
    case 'timer-reset': timerReset('work'); break;
    case 'export': {
      const blob = new Blob([JSON.stringify(S, null, 2)], { type: 'application/json' });
      const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
      a.download = `studyquest-${todayStr()}.json`; a.click(); URL.revokeObjectURL(a.href); break;
    }
    case 'import': $('importFile').click(); break;
    case 'reset':
      if (confirm('本当に全データを消去しますか?元に戻せません。')) { Store.clear(); S = Store.load(); save(); toast('初期化しました'); } break;
  }
});

$('taskForm').addEventListener('submit', (e) => {
  e.preventDefault();
  S.tasks.push({ id: uid(), title: $('tTitle').value.trim(), subject: $('tSubject').value,
    due: $('tDue').value, prio: +$('tPrio').value, done: false });
  $('tTitle').value = '';
  save(); toast('追加しました ✅');
});

$('fStatus').addEventListener('click', (e) => {
  const b = e.target.closest('button'); if (!b) return;
  filt.status = b.dataset.f;
  document.querySelectorAll('#fStatus button').forEach(x => x.classList.toggle('on', x === b));
  renderTasks();
});
$('fSubject').addEventListener('change', (e) => { filt.subject = e.target.value; renderTasks(); });
$('fSearch').addEventListener('input', (e) => { filt.q = e.target.value; renderTasks(); });

$('sName').addEventListener('change', (e) => { S.name = e.target.value.trim(); save(); });
$('sTheme').addEventListener('change', (e) => { S.theme = e.target.value; save(); });
$('workMin').addEventListener('change', (e) => { S.focus.work = Math.max(1, +e.target.value || 25); Store.save(S); if (!T.run) timerReset(T.mode); });
$('restMin').addEventListener('change', (e) => { S.focus.rest = Math.max(1, +e.target.value || 5); Store.save(S); if (!T.run) timerReset(T.mode); });

$('importFile').addEventListener('change', (e) => {
  const f = e.target.files[0]; if (!f) return;
  const r = new FileReader();
  r.onload = () => {
    try {
      const data = JSON.parse(r.result);
      if (!Array.isArray(data.subjects) || !Array.isArray(data.tasks)) throw new Error('形式が違います');
      S = Object.assign(defaults(), data); save(); toast('読み込みました ✅');
    } catch (err) { alert('読み込みに失敗しました:' + err.message); }
  };
  r.readAsText(f); e.target.value = '';
});

$('sdCancel').onclick = () => $('subjectDialog').close();
$('sdDelete').onclick = () => {
  if (confirm('この教科と、紐づく課題を削除しますか?')) {
    S.subjects = S.subjects.filter(s => s.id !== editingId);
    S.tasks = S.tasks.filter(t => t.subject !== editingId);
    $('subjectDialog').close(); save();
  }
};
$('subjectForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const total = Math.max(1, +$('sdTotal').value || 1);
  const data = { name: $('sdName').value.trim(), emoji: $('sdEmoji').value || '📚', color: $('sdColor').value,
    unit: $('sdUnit').value || '個', total, done: Math.max(0, Math.min(total, +$('sdDone').value || 0)) };
  if (editingId) Object.assign(subj(editingId), data); else S.subjects.push(Object.assign({ id: uid() }, data));
  $('subjectDialog').close(); save();
});

matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyTheme);

// 日付の初期値(今日)
$('tDue').min = todayStr();

render();

// PWA: オフライン対応
if ('serviceWorker' in navigator) {
  addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => {}));
}
